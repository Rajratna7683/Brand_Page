import './App.css'

const App = () => {
  return (
    <div className="container">
        {/* Navigation Section */}
        <div className="nav_section">
        <img src="/images/brand_logo.png" alt="Brand Logo" />
        <ul>
          <li>MENU</li>
          <li>LOCATION</li>
          <li>ABOUT</li>
          <li>CONTACT</li>
        </ul>
        <button>Login</button>
        </div>
        {/* Body Section */}
        <div className='body_section'>
          <div className='content'>
            <h1>Your Feet Deserve The Best</h1>
            <p>YOUR FEET DESERVE THE BEST AND WE’RE HERE TO 
              HELP YOU WITH OUR SHOES.YOUR FEET DESERVE 
              THE BEST AND WE’RE HERE TO HELP YOU WITH OUR SHOES.</p>
              <div className='btn_section'>
              <button>Shop Now</button>
              <button>Category</button>
              </div>
              <p>Also Available On</p>
              <div className='img_section'>
                <img src="/images/flipkart.png" alt="Image Not Found" />
                <img src="/images/amazon.png" alt="Image Not Found" />
              </div>
          </div>
          <div className='body_img'></div>
          <img src="/images/hero-image.png" alt="Hero Image" />
        </div>
    </div>
  );
};

export default App;